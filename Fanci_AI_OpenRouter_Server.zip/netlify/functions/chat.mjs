export default async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("", { status: 204, headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    }});
  }
  if (req.method !== "POST") return new Response(JSON.stringify({error:"Use POST"}), {status:405,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
  try {
    const { message } = await req.json();
    if (!message) return new Response(JSON.stringify({error:"message is required"}), {status:400,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
    const key = process.env.OPENROUTER_API_KEY;
    if (!key) return new Response(JSON.stringify({error:"Server API key is not configured"}), {status:500,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method:"POST",
      headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:"openrouter/free",
        messages:[
          {role:"system",content:"You are Fanci AI, a friendly helpful assistant. Answer clearly and naturally."},
          {role:"user",content:message}
        ]
      })
    });
    const data = await r.json();
    if (!r.ok) return new Response(JSON.stringify({error:data?.error?.message || "OpenRouter request failed"}), {status:r.status,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
    return new Response(JSON.stringify({reply:data?.choices?.[0]?.message?.content || "Maaf, Fanci belum mendapat jawaban."}), {status:200,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
  } catch {
    return new Response(JSON.stringify({error:"Invalid request"}), {status:500,headers:{"Content-Type":"application/json","Access-Control-Allow-Origin":"*"}});
  }
};
