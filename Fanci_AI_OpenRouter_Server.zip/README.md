Fanci AI OpenRouter server.

Set OPENROUTER_API_KEY as a secret environment variable on the server. Never put the key inside the APK/frontend.
